<?php
/**
 * Intentionally empty file.
 *
 * It exists to stop directory listings on poorly configured servers.
 *
 * @package     Cp_Plgn_Drctry
 * @subpackage  Cp_Plgn_Drctry/includes
 */
